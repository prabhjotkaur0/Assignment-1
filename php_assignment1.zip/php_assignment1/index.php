<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Records</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <header>
        <div class="logo">Student Records</div>
        <nav>
            <a href="index.php">Add Record</a>
            <a href="view.php">View Records</a>
        </nav>
    </header>
    <main>
        <form method="post">
            <div class="input-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="input-group">
                <label for="grade">Grade:</label>
                <input type="text" id="grade" name="grade" required>
            </div>
            <div class="input-group">
                <label for="subject">Subject:</label>
                <input type="text" id="subject" name="subject" required>
            </div>
            <div class="input-group">
                <label for="email">Email::</label>
                <input type="text" id="email" name="email" required>
            </div>
            <button type="submit">Add Record</button>
        </form>
        <div class="form-group submit-message">
            <?php
            require_once('database.php');
            
            if (!empty($_POST)) {
                $name = $_POST['name'];
                $grade = $_POST['grade'];
                $subject = $_POST['subject'];
                $email = $_POST['email'];
                $res = $database->create($name, $grade, $subject, $email);
                if ($res) {
                    echo "<p>Successfully inserted data</p>";
                } else {
                    echo "<p>Failed to insert data</p>";
                }
            }
            ?>
        </div>
    </main>
    <footer>
        &copy; 2023 Student Records
    </footer>
</body>

</html>