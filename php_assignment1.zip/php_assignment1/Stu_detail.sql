CREATE TABLE StudentPortal (
    id(255) AUTO INCREMENT,
  name varchar(255) NOT NULL,
  grade varchar(255) NOT NULL,
  subject varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  primary key (id)
);

INSERT into StudentPortal(name, grade, subject, email)
VALUES
('2', 'Prabh', '100', 'kaurprabhjot0071@gmail.com'),
('3', 'Barkirat singh', '99', 'Maths', 'barkirat998@gmail.com'),
('4', 'Gurleen Kaur', '98' 'History', 'gurleenkahlon123@gmail.com'),
