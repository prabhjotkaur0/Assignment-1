<?php
// Create a class to manage database operations.
class Database {
    // Private property to store the database connection.
    private $connection;

    // Constructor to automatically connect to the database.
    function __construct() {
        $this->connect_db();
    }

    // Method to establish a database connection.
    public function connect_db() {
        $this->connection = mysqli_connect('localhost', 'root', '', 'database');

        // Check for a connection error and exit if one occurs.
        if (mysqli_connect_error()) {
            die("Database Connection Failed: " . mysqli_connect_error());
        }
    }

    // Method to create a new record in the database.
    public function create($name, $grade, $subject, $email) {
        $sql = "INSERT INTO stu_details (name, grade, subject, email) VALUES ('$name', '$grade', '$subject', '$email')";
        $res = mysqli_query($this->connection, $sql);

        // Return true if the insertion was successful, false otherwise.
        if ($res) {
            return true;
        } else {
            return false;
        }
    }

    // Method to retrieve records from the database.
    public function read() {
        $sql = "SELECT * FROM stu_details";
        $res = mysqli_query($this->connection, $sql);

        // Return the result set.
        return $res;
    }
}

// Create an instance of the Database class.
$database = new Database();
?>
